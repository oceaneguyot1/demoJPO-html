# demoJPO

Projet décomposé sur les différentes étapes d'un site web

## branches
- html : juste le html
- css : html + css
- responsive : html + css + responsive avec bootstrap
- js : html + css + responsive avec bootstrap + js
